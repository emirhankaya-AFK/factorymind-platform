"""
Script to generate sample data for FactoryMind demo
"""
import random
from datetime import datetime, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .services.api import models

# Use SQLite for demo
SQLALCHEMY_DATABASE_URL = "sqlite:///./factorymind.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def create_sample_data():
    db = SessionLocal()
    try:
        # Create organizations
        org1 = models.Organization(name="FactoryMind Inc.")
        db.add(org1)
        db.commit()
        db.refresh(org1)
        
        # Create factories
        factory1 = models.Factory(name="Main Plant", location="Building A", timezone="UTC", organization_id=org1.id)
        factory2 = models.Factory(name="Secondary Plant", location="Building B", timezone="UTC", organization_id=org1.id)
        db.add_all([factory1, factory2])
        db.commit()
        db.refresh(factory1)
        db.refresh(factory2)
        
        # Create lines
        line1 = models.Line(name="Assembly Line 1", factory_id=factory1.id)
        line2 = models.Line(name="Assembly Line 2", factory_id=factory1.id)
        line3 = models.Line(name="Packaging Line", factory_id=factory2.id)
        db.add_all([line1, line2, line3])
        db.commit()
        db.refresh(line1)
        db.refresh(line2)
        db.refresh(line3)
        
        # Create machines
        machines = [
            models.Machine(name="CNC Mill 1", type="CNC", line_id=line1.id, status="active"),
            models.Machine(name="Robot Arm 1", type="Robot", line_id=line1.id, status="active"),
            models.Machine(name="Conveyor Belt 1", type="Conveyor", line_id=line2.id, status="active"),
            models.Machine(name="Packager 1", type="Packager", line_id=line3.id, status="active"),
            models.Machine(name="Test Machine", type="Test", line_id=line1.id, status="maintenance"),
        ]
        db.add_all(machines)
        db.commit()
        
        # Generate some telemetry data
        for machine in machines:
            for i in range(10):
                timestamp = datetime.utcnow() - timedelta(minutes=i*5)
                readings = {
                    "temperature": round(random.uniform(20, 30), 2),
                    "vibration": round(random.uniform(0, 1), 2),
                    "pressure": round(random.uniform(100, 102), 2),
                    "humidity": round(random.uniform(40, 60), 2)
                }
                telemetry = models.TelemetryReading(
                    machine_id=machine.id,
                    timestamp=timestamp,
                    readings=readings
                )
                db.add(telemetry)
        
        db.commit()
        print("Sample data created successfully!")
        
    except Exception as e:
        print(f"Error creating sample data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    create_sample_data()