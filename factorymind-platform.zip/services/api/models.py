from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Boolean, Text, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base
import enum

class Organization(Base):
    __tablename__ = "organizations"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    factories = relationship("Factory", back_populates="organization")

class Factory(Base):
    __tablename__ = "factories"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    location = Column(String)
    timezone = Column(String, default="UTC")
    organization_id = Column(Integer, ForeignKey("organizations.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    organization = relationship("Organization", back_populates="factories")
    lines = relationship("Line", back_populates="factory")

class Line(Base):
    __tablename__ = "lines"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    factory_id = Column(Integer, ForeignKey("factories.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    factory = relationship("Factory", back_populates="lines")
    machines = relationship("Machine", back_populates="line")

class Machine(Base):
    __tablename__ = "machines"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    type = Column(String)  # e.g., CNC, Robot, Conveyor
    line_id = Column(Integer, ForeignKey("lines.id"))
    status = Column(String, default="active")  # active, inactive, maintenance
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    line = relationship("Line", back_populates="machines")
    telemetry = relationship("TelemetryReading", back_populates="machine")
    inspections = relationship("Inspection", back_populates="machine")
    tickets = relationship("MaintenanceTicket", back_populates="machine")

class TelemetryReading(Base):
    __tablename__ = "telemetry_readings"
    
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"))
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    readings = Column(JSON)  # Store sensor readings as JSON
    
    # Relationships
    machine = relationship("Machine", back_populates="telemetry")

class DefectType(str, enum.Enum):
    SCRATCH = "scratch"
    DENT = "dent"
    DISCOLORATION = "discoloration"
    MISSING_PART = "missing_part"
    MISALIGNMENT = "misalignment"

class Inspection(Base):
    __tablename__ = "inspections"
    
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"))
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    image_url = Column(String)
    inspector_id = Column(Integer)  # Reference to user/operator
    defects = Column(JSON)  # List of detected defects
    score = Column(Float)  # Anomaly score (0-1)
    status = Column(String, default="completed")  # pending, completed, failed
    
    # Relationships
    machine = relationship("Machine", back_populates="inspections")

class AlertSeverity(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AlertStatus(str, enum.Enum):
    ACTIVE = "active"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"

class Alert(Base):
    __tablename__ = "alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"))
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    severity = Column(String)  # AlertSeverity
    status = Column(String, default=AlertStatus.ACTIVE)  # AlertStatus
    title = Column(String)
    description = Column(Text)
    source = Column(String)  # telemetry, inspection, model
    metadata = Column(JSON)  # Additional context
    
    # Relationships
    machine = relationship("Machine")

class TicketPriority(str, enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class TicketStatus(str, enum.Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CLOSED = "closed"

class MaintenanceTicket(Base):
    __tablename__ = "maintenance_tickets"
    
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"))
    title = Column(String)
    description = Column(Text)
    priority = Column(String)  # TicketPriority
    status = Column(String, default=TicketStatus.OPEN)  # TicketStatus
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    assigned_to = Column(Integer)  # User ID
    
    # Relationships
    machine = relationship("Machine", back_populates="tickets")

class ModelRun(Base):
    __tablename__ = "model_runs"
    
    id = Column(Integer, primary_key=True, index=True)
    machine_id = Column(Integer, ForeignKey("machines.id"))
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
    model_type = Column(String)  # e.g., anomaly_detection, failure_prediction
    model_version = Column(String)
    inputs = Column(JSON)  # Input features
    outputs = Column(JSON)  # Model predictions
    metrics = Column(JSON)  # Performance metrics
    
    # Relationships
    machine = relationship("Machine")
