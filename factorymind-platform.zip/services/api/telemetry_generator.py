import asyncio
import random
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np
from . import models, database
from .config import settings

class SyntheticTelemetryGenerator:
    def __init__(self):
        self.running = False
        self.task = None
        
    async def generate_telemetry_for_machine(self, machine_id: int, db_session):
        """Generate deterministic synthetic telemetry for a machine"""
        # Base values for different sensor types
        base_values = {
            "temperature": 25.0,
            "vibration": 0.1,
            "pressure": 101.3,
            "humidity": 45.0,
            "current": 2.0,
            "voltage": 220.0
        }
        
        # Add some machine-specific variation
        machine_hash = hash(str(machine_id)) % 100
        for key in base_values:
            base_values[key] += (machine_hash - 50) * 0.1
        
        while self.running:
            # Generate readings with some noise and occasional anomalies
            readings = {}
            timestamp = datetime.utcnow()
            
            for sensor, base in base_values.items():
                # Normal operation with Gaussian noise
                value = base + random.gauss(0, base * 0.05)
                
                # Occasionally inject anomalies (1% chance)
                if random.random() < 0.01:
                    if sensor == "temperature":
                        value += random.uniform(10, 30)  # Spike
                    elif sensor == "vibration":
                        value *= random.uniform(3, 5)   # Spike
                    elif sensor == "pressure":
                        value += random.uniform(-20, 20) # Drop/spike
                
                readings[sensor] = round(value, 2)
            
            # Create telemetry record
            telemetry = models.TelemetryReading(
                machine_id=machine_id,
                timestamp=timestamp,
                readings=readings
            )
            
            db_session.add(telemetry)
            db_session.commit()
            
            # Wait for next interval
            await asyncio.sleep(settings.telemetry_flush_interval)
    
    async def start(self, machine_ids: List[int]):
        """Start generating telemetry for multiple machines"""
        if self.running:
            return
        
        self.running = True
        # In a real app, we'd manage DB sessions properly
        # For simplicity, we'll create a session per machine
        tasks = []
        for machine_id in machine_ids:
            task = asyncio.create_task(self._generate_for_machine(machine_id))
            tasks.append(task)
        
        self.task = asyncio.gather(*tasks)
    
    async def _generate_for_machine(self, machine_id: int):
        from .database import SessionLocal
        db = SessionLocal()
        try:
            await self.generate_telemetry_for_machine(machine_id, db)
        finally:
            db.close()
    
    async def stop(self):
        """Stop telemetry generation"""
        self.running = False
        if self.task:
            await self.task
            self.task = None

# Global generator instance
telemetry_generator = SyntheticTelemetryGenerator()