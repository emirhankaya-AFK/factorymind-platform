from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from .. import models, schemas, database
from ..dependencies import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.FactoryResponse])
def get_factories(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    factories = db.query(models.Factory).offset(skip).limit(limit).all()
    return factories

@router.post("/", response_model=schemas.FactoryResponse, status_code=status.HTTP_201_CREATED)
def create_factory(
    factory: schemas.FactoryCreate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Check if organization exists
    organization = db.query(models.Organization).filter(models.Organization.id == factory.organization_id).first()
    if not organization:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    db_factory = models.Factory(**factory.dict())
    db.add(db_factory)
    db.commit()
    db.refresh(db_factory)
    return db_factory

@router.get("/{factory_id}", response_model=schemas.FactoryResponse)
def get_factory(
    factory_id: int,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    factory = db.query(models.Factory).filter(models.Factory.id == factory_id).first()
    if factory is None:
        raise HTTPException(status_code=404, detail="Factory not found")
    return factory
