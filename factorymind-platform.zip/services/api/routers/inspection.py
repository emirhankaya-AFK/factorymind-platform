from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.orm import Session
from typing import List, Optional
from .. import models, schemas, database, inspection
from ..dependencies import get_current_user

router = APIRouter()

@router.post("/", response_model=schemas.InspectionResponse, status_code=status.HTTP_201_CREATED)
def create_inspection(
    inspection: schemas.InspectionCreate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Check if machine exists
    machine = db.query(models.Machine).filter(models.Machine.id == inspection.machine_id).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    
    db_inspection = models.Inspection(**inspection.dict())
    db.add(db_inspection)
    db.commit()
    db.refresh(db_inspection)
    return db_inspection

@router.post("/{machine_id}/upload", response_model=schemas.InspectionResponse)
async def upload_and_inspect(
    machine_id: int,
    file: UploadFile = File(...),
    inspector_id: Optional[int] = None,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Check if machine exists
    machine = db.query(models.Machine).filter(models.Machine.id == machine_id).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    
    # Read image data
    image_data = await file.read()
    
    # Run inspection
    result = inspection_service.inspect_image(image_data)
    
    # Create inspection record
    inspection_data = schemas.InspectionCreate(
        machine_id=machine_id,
        image_url=f"/uploads/{file.filename}",  # In real app, store file and return URL
        inspector_id=inspector_id or current_user.get("id")
    )
    
    db_inspection = models.Inspection(
        **inspection_data.dict(),
        defects=result["defects"],
        score=result["score"]
    )
    
    db.add(db_inspection)
    db.commit()
    db.refresh(db_inspection)
    return db_inspection

@router.get("/{inspection_id}", response_model=schemas.InspectionResponse)
def get_inspection(
    inspection_id: int,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    inspection = db.query(models.Inspection).filter(models.Inspection.id == inspection_id).first()
    if inspection is None:
        raise HTTPException(status_code=404, detail="Inspection not found")
    return inspection

@router.get("/", response_model=List[schemas.InspectionResponse])
def get_inspections(
    machine_id: Optional[int] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    query = db.query(models.Inspection)
    if machine_id:
        query = query.filter(models.Inspection.machine_id == machine_id)
    inspections = query.offset(skip).limit(limit).all()
    return inspections
