from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from .. import models, schemas, database
from ..dependencies import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.TicketResponse])
def get_tickets(
    machine_id: Optional[int] = None,
    status: Optional[str] = None,
    priority: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    query = db.query(models.MaintenanceTicket)
    if machine_id:
        query = query.filter(models.MaintenanceTicket.machine_id == machine_id)
    if status:
        query = query.filter(models.MaintenanceTicket.status == status)
    if priority:
        query = query.filter(models.MaintenanceTicket.priority == priority)
    
    tickets = query.offset(skip).limit(limit).all()
    return tickets

@router.get("/{ticket_id}", response_model=schemas.TicketResponse)
def get_ticket(
    ticket_id: int,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    ticket = db.query(models.MaintenanceTicket).filter(models.MaintenanceTicket.id == ticket_id).first()
    if ticket is None:
        raise HTTPException(status_code=404, detail="Ticket not found")
    return ticket

@router.patch("/{ticket_id}", response_model=schemas.TicketResponse)
def update_ticket(
    ticket_id: int,
    update: schemas.TicketUpdate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    ticket = db.query(models.MaintenanceTicket).filter(models.MaintenanceTicket.id == ticket_id).first()
    if ticket is None:
        raise HTTPException(status_code=404, detail="Ticket not found")
    
    if update.status is not None:
        ticket.status = update.status
    if update.assigned_to is not None:
        ticket.assigned_to = update.assigned_to
    
    db.commit()
    db.refresh(ticket)
    return ticket

@router.post("/", response_model=schemas.TicketResponse, status_code=status.HTTP_201_CREATED)
def create_ticket(
    ticket: schemas.TicketCreate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Check if machine exists
    machine = db.query(models.Machine).filter(models.Machine.id == ticket.machine_id).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    
    db_ticket = models.MaintenanceTicket(**ticket.dict())
    db.add(db_ticket)
    db.commit()
    db.refresh(db_ticket)
    return db_ticket
