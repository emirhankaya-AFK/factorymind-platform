from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from .. import models, schemas, database
from ..dependencies import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.AlertResponse])
def get_alerts(
    machine_id: Optional[int] = None,
    status: Optional[str] = None,
    severity: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    query = db.query(models.Alert)
    if machine_id:
        query = query.filter(models.Alert.machine_id == machine_id)
    if status:
        query = query.filter(models.Alert.status == status)
    if severity:
        query = query.filter(models.Alert.severity == severity)
    
    alerts = query.offset(skip).limit(limit).all()
    return alerts

@router.get("/{alert_id}", response_model=schemas.AlertResponse)
def get_alert(
    alert_id: int,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    alert = db.query(models.Alert).filter(models.Alert.id == alert_id).first()
    if alert is None:
        raise HTTPException(status_code=404, detail="Alert not found")
    return alert

@router.patch("/{alert_id}/acknowledge", response_model=schemas.AlertResponse)
def acknowledge_alert(
    alert_id: int,
    update: schemas.AlertUpdate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    alert = db.query(models.Alert).filter(models.Alert.id == alert_id).first()
    if alert is None:
        raise HTTPException(status_code=404, detail="Alert not found")
    
    alert.status = update.status
    if update.acknowledged_by:
        # In a real app, we'd store who acknowledged it
        pass
    
    db.commit()
    db.refresh(alert)
    return alert

@router.post("/", response_model=schemas.AlertResponse, status_code=status.HTTP_201_CREATED)
def create_alert(
    alert: schemas.AlertCreate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Check if machine exists
    machine = db.query(models.Machine).filter(models.Machine.id == alert.machine_id).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    
    db_alert = models.Alert(**alert.dict())
    db.add(db_alert)
    db.commit()
    db.refresh(db_alert)
    return db_alert
