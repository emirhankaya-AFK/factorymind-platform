from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from .. import models, schemas, database
from ..dependencies import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.ModelRunResponse])
def get_model_runs(
    machine_id: Optional[int] = None,
    model_type: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    query = db.query(models.ModelRun)
    if machine_id:
        query = query.filter(models.ModelRun.machine_id == machine_id)
    if model_type:
        query = query.filter(models.ModelRun.model_type == model_type)
    
    runs = query.offset(skip).limit(limit).all()
    return runs

@router.get("/{run_id}", response_model=schemas.ModelRunResponse)
def get_model_run(
    run_id: int,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    run = db.query(models.ModelRun).filter(models.ModelRun.id == run_id).first()
    if run is None:
        raise HTTPException(status_code=404, detail="Model run not found")
    return run

@router.post("/", response_model=schemas.ModelRunResponse, status_code=status.HTTP_201_CREATED)
def create_model_run(
    model_run: schemas.ModelRunCreate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Check if machine exists
    machine = db.query(models.Machine).filter(models.Machine.id == model_run.machine_id).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")
    
    db_run = models.ModelRun(**model_run.dict())
    db.add(db_run)
    db.commit()
    db.refresh(db_run)
    return db_run
