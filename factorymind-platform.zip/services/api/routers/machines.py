from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from .. import models, schemas, database
from ..dependencies import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.MachineResponse])
def get_machines(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    machines = db.query(models.Machine).offset(skip).limit(limit).all()
    return machines

@router.post("/", response_model=schemas.MachineResponse, status_code=status.HTTP_201_CREATED)
def create_machine(
    machine: schemas.MachineCreate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Check if line exists
    line = db.query(models.Line).filter(models.Line.id == machine.line_id).first()
    if not line:
        raise HTTPException(status_code=404, detail="Line not found")
    
    db_machine = models.Machine(**machine.dict())
    db.add(db_machine)
    db.commit()
    db.refresh(db_machine)
    return db_machine

@router.get("/{machine_id}", response_model=schemas.MachineResponse)
def get_machine(
    machine_id: int,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    machine = db.query(models.Machine).filter(models.Machine.id == machine_id).first()
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return machine
