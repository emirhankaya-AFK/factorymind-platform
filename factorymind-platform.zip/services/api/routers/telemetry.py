from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from .. import models, schemas, database, telemetry_generator
from ..dependencies import get_current_user

router = APIRouter()

@router.post("/ingest", response_model=schemas.TelemetryReadingResponse)
def ingest_telemetry(
    telemetry: schemas.TelemetryReadingCreate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Set timestamp if not provided
    if telemetry.timestamp is None:
        telemetry.timestamp = datetime.utcnow()
    
    db_telemetry = models.TelemetryReading(**telemetry.dict())
    db.add(db_telemetry)
    db.commit()
    db.refresh(db_telemetry)
    return db_telemetry

@router.get("/", response_model=List[schemas.TelemetryReadingResponse])
def query_telemetry(
    machine_id: Optional[int] = None,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    query = db.query(models.TelemetryReading)
    
    if machine_id:
        query = query.filter(models.TelemetryReading.machine_id == machine_id)
    if start_time:
        query = query.filter(models.TelemetryReading.timestamp >= start_time)
    if end_time:
        query = query.filter(models.TelemetryReading.timestamp <= end_time)
    
    telemetry = query.order_by(models.TelemetryReading.timestamp.desc()).limit(limit).all()
    return telemetry

# Background telemetry generation (for demo)
@router.post("/generate-synthetic", status_code=status.HTTP_202_ACCEPTED)
def start_synthetic_telegram(
    machine_ids: List[int],
    current_user: dict = Depends(get_current_user)
):
    if not settings.enable_synthetic_telemetry:
        raise HTTPException(status_code=403, detail="Synthetic telemetry disabled")
    
    # Start background task
    # In a real app, we'd use a proper task queue
    import asyncio
    asyncio.create_task(telemetry_generator.start(machine_ids))
    return {"message": "Synthetic telemetry generation started"}
