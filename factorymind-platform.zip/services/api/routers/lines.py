from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from .. import models, schemas, database
from ..dependencies import get_current_user

router = APIRouter()

@router.get("/", response_model=List[schemas.LineResponse])
def get_lines(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    lines = db.query(models.Line).offset(skip).limit(limit).all()
    return lines

@router.post("/", response_model=schemas.LineResponse, status_code=status.HTTP_201_CREATED)
def create_line(
    line: schemas.LineCreate,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    # Check if factory exists
    factory = db.query(models.Factory).filter(models.Factory.id == line.factory_id).first()
    if not factory:
        raise HTTPException(status_code=404, detail="Factory not found")
    
    db_line = models.Line(**line.dict())
    db.add(db_line)
    db.commit()
    db.refresh(db_line)
    return db_line

@router.get("/{line_id}", response_model=schemas.LineResponse)
def get_line(
    line_id: int,
    db: Session = Depends(database.get_db),
    current_user: dict = Depends(get_current_user)
):
    line = db.query(models.Line).filter(models.Line.id == line_id).first()
    if line is None:
        raise HTTPException(status_code=404, detail="Line not found")
    return line
