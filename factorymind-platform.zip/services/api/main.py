from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn
from . import models, schemas, database, telemetry_generator, inspection
from .routers import factories, lines, machines, telemetry, inspection as inspection_router, alerts, tickets, model_runs
from .websocket import websocket_endpoint
from .background_jobs import start_background_workers, stop_background_workers
from .config import settings

# Create database models
models.Base.metadata.create_all(bind=database.engine)

# Security
security = HTTPBearer()

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    # In a real app, validate JWT token here
    # For MVP, we'll return a mock user
    return {"id": 1, "username": "admin", "role": "admin"}

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    await database.connect()
    start_background_workers()
    yield
    # Shutdown
    stop_background_workers()
    await database.disconnect()

app = FastAPI(
    title="FactoryMind API",
    description="Industrial AI Operations Platform",
    version="0.1.0",
    lifespan=lifespan
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure properly in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(factories.router, prefix="/factories", tags=["factories"])
app.include_router(lines.router, prefix="/lines", tags=["lines"])
app.include_router(machines.router, prefix="/machines", tags=["machines"])
app.include_router(telemetry.router, prefix="/telemetry", tags=["telemetry"])
app.include_router(inspection_router.router, prefix="/inspections", tags=["inspection"])
app.include_router(alerts.router, prefix="/alerts", tags=["alerts"])
app.include_router(tickets.router, prefix="/tickets", tags=["tickets"])
app.include_router(model_runs.router, prefix="/model-runs", tags=["model-runs"])

# WebSocket endpoint
app.add_api_websocket_route("/ws/telemetry", websocket_endpoint)

# Health check
@app.get("/health", tags=["health"])
async def health_check():
    return {"status": "healthy", "service": "factorymind-api"}

# Metrics endpoint
@app.get("/metrics", tags=["metrics"])
async def metrics():
    # In a real app, return Prometheus metrics
    return {"message": "Metrics endpoint - implement with Prometheus client"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
