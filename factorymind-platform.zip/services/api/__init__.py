"""FactoryMind API package."""
