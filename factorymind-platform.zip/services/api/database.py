from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import StaticPool
import os
from .config import settings

# Database URL from environment, default to SQLite for demo
SQLALCHEMY_DATABASE_URL = settings.database_url

# For SQLite, we need special arguments
if SQLALCHEMY_DATABASE_URL.startswith("sqlite"):
    engine = create_engine(
        SQLALCHEMY_DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
else:
    engine = create_engine(SQLALCHEMY_DATABASE_URL)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Async database connection (for demo, we'll use sync but structure for async)
class Database:
    def __init__(self):
        self.engine = engine
        self.SessionLocal = SessionLocal
    
    async def connect(self):
        # In a real async app, we'd use async engine
        return None
    
    async def disconnect(self):
        return None
    
    def get_session(self) -> Session:
        return self.SessionLocal()

db = Database()
