from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class Settings(BaseSettings):
    # Application
    app_name: str = "FactoryMind"
    debug: bool = False
    
    # Database
    database_url: str = Field(
        default="sqlite:///./factorymind.db",
        env="DATABASE_URL"
    )
    
    # Security
    secret_key: str = Field(default="your-secret-key-here", env="SECRET_KEY")
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # Telemetry
    telemetry_batch_size: int = 100
    telemetry_flush_interval: int = 5
    
    # Inspection
    inspection_model_path: str = Field(default="models/anomaly_detector.onnx", env="INSPECTION_MODEL_PATH")
    opencv_headless: bool = True
    
    # WebSocket
    ws_heartbeat_interval: int = 25
    
    # Background Jobs
    job_worker_count: int = 2
    job_queue_size: int = 1000
    
    # Feature Flags
    enable_synthetic_telemetry: bool = True
    enable_inspection: bool = True
    enable_alerts: bool = True
    enable_tickets: bool = True
    
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

settings = Settings()
