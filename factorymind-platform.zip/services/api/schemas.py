from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from . import models

# Organization
class OrganizationBase(BaseModel):
    name: str

class OrganizationCreate(OrganizationBase):
    pass

class OrganizationResponse(OrganizationBase):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Factory
class FactoryBase(BaseModel):
    name: str
    location: Optional[str] = None
    timezone: str = "UTC"

class FactoryCreate(FactoryBase):
    organization_id: int

class FactoryResponse(FactoryBase):
    id: int
    organization_id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Line
class LineBase(BaseModel):
    name: str

class LineCreate(LineBase):
    factory_id: int

class LineResponse(LineBase):
    id: int
    factory_id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Machine
class MachineBase(BaseModel):
    name: str
    type: Optional[str] = None
    status: str = "active"

class MachineCreate(MachineBase):
    line_id: int

class MachineResponse(MachineBase):
    id: int
    line_id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Telemetry
class TelemetryReadingBase(BaseModel):
    machine_id: int
    timestamp: Optional[datetime] = None
    readings: Dict[str, Any]

class TelemetryReadingCreate(TelemetryReadingBase):
    pass

class TelemetryReadingResponse(TelemetryReadingBase):
    id: int
    machine_id: int
    timestamp: datetime
    
    class Config:
        from_attributes = True

class TelemetryQuery(BaseModel):
    machine_id: Optional[int] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    limit: int = Field(100, lte=1000)

# Inspection
class DefectInfo(BaseModel):
    type: str
    confidence: float
    bounding_box: Optional[List[int]] = None  # [x, y, width, height]

class InspectionBase(BaseModel):
    machine_id: int
    image_url: str
    inspector_id: Optional[int] = None

class InspectionCreate(InspectionBase):
    pass

class InspectionResponse(InspectionBase):
    id: int
    machine_id: int
    timestamp: datetime
    image_url: str
    inspector_id: Optional[int]
    defects: List[DefectInfo]
    score: float
    status: str
    
    class Config:
        from_attributes = True

# Alert
class AlertBase(BaseModel):
    machine_id: int
    severity: str
    title: str
    description: Optional[str] = None
    source: str
    metadata: Optional[Dict[str, Any]] = None

class AlertCreate(AlertBase):
    pass

class AlertResponse(AlertBase):
    id: int
    machine_id: int
    timestamp: datetime
    severity: str
    status: str
    title: str
    description: Optional[str]
    source: str
    metadata: Optional[Dict[str, Any]]
    
    class Config:
        from_attributes = True

class AlertUpdate(BaseModel):
    status: str
    acknowledged_by: Optional[int] = None

# Maintenance Ticket
class TicketBase(BaseModel):
    machine_id: int
    title: str
    description: Optional[str] = None
    priority: str = "medium"

class TicketCreate(TicketBase):
    pass

class TicketResponse(TicketBase):
    id: int
    machine_id: int
    title: str
    description: Optional[str]
    priority: str
    status: str
    created_at: datetime
    updated_at: Optional[datetime]
    assigned_to: Optional[int]
    
    class Config:
        from_attributes = True

class TicketUpdate(BaseModel):
    status: Optional[str] = None
    assigned_to: Optional[int] = None

# Model Run
class ModelRunBase(BaseModel):
    machine_id: int
    model_type: str
    model_version: str
    inputs: Dict[str, Any]
    outputs: Dict[str, Any]
    metrics: Optional[Dict[str, Any]] = None

class ModelRunCreate(ModelRunBase):
    pass

class ModelRunResponse(ModelRunBase):
    id: int
    machine_id: int
    timestamp: datetime
    model_type: str
    model_version: str
    inputs: Dict[str, Any]
    outputs: Dict[str, Any]
    metrics: Optional[Dict[str, Any]]
    
    class Config:
        from_attributes = True

# Token
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None