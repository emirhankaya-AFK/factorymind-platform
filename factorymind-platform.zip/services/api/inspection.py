import cv2
import numpy as np
import os
from typing import List, Dict, Any, Optional
try:
    import onnxruntime as ort
except ImportError:  # Optional acceleration; OpenCV fallback remains available.
    ort = None
from . import models
from .config import settings

class InspectionService:
    def __init__(self):
        self.model = None
        self.model_path = settings.inspection_model_path
        self._load_model()
    
    def _load_model(self):
        """Load ONNX model for anomaly detection"""
        try:
            # For MVP, we'll use a simple OpenCV-based approach if model not available
            # In production, load the ONNX model
            if ort is not None and os.path.exists(self.model_path):
                self.model = ort.InferenceSession(self.model_path)
            else:
                # Fallback to OpenCV-based anomaly detection
                self.model = None
        except Exception as e:
            print(f"Warning: Could not load inspection model: {e}")
            self.model = None
    
    def preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """Preprocess image for model input"""
        # Resize to model input size
        resized = cv2.resize(image, (224, 224))
        # Normalize
        normalized = resized.astype(np.float32) / 255.0
        # Add batch dimension
        batch = np.expand_dims(normalized, axis=0)
        return batch
    
    def detect_anomalies_opencv(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """Simple anomaly detection using OpenCV (for MVP)"""
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Use adaptive threshold to find potential defects
        thresh = cv2.adaptiveThreshold(
            blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY_INV, 11, 2
        )
        
        # Find contours
        contours, _ = cv2.findContours(
            thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        
        defects = []
        for contour in contours:
            area = cv2.contourArea(contour)
            # Filter by area to remove noise
            if 50 < area < 5000:
                x, y, w, h = cv2.boundingRect(contour)
                # Simple classification based on aspect ratio and area
                aspect_ratio = w / float(h)
                if aspect_ratio > 2 or aspect_ratio < 0.5:
                    defect_type = "scratch"
                elif area > 1000:
                    defect_type = "dent"
                else:
                    defect_type = "unknown"
                
                defects.append({
                    "type": defect_type,
                    "confidence": min(0.9, area / 1000.0),  # Simple confidence
                    "bounding_box": [int(x), int(y), int(w), int(h)]
                })
        
        return defects
    
    def inspect_image(self, image_data: bytes) -> Dict[str, Any]:
        """Run inspection on image data"""
        # Convert bytes to OpenCV image
        nparr = np.frombuffer(image_data, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        if image is None:
            raise ValueError("Could not decode image")
        
        defects = []
        score = 0.0
        
        if self.model is not None:
            # Use ONNX model
            try:
                batch = self.preprocess_image(image)
                inputs = {self.model.get_inputs()[0].name: batch}
                outputs = self.model.run(None, inputs)
                # Process outputs to get defects and score
                # This is model-specific; for MVP we'll use dummy values
                score = float(outputs[0][0][0])  # Simplified
                defects = [{"type": "anomaly", "confidence": score, "bounding_box": [0,0,0,0]}]
            except Exception as e:
                print(f"Error running inspection model: {e}")
                # Fallback to OpenCV
                defects = self.detect_anomalies_opencv(image)
                score = min(1.0, len(defects) * 0.2)
        else:
            # Use OpenCV-based detection
            defects = self.detect_anomalies_opencv(image)
            score = min(1.0, len(defects) * 0.2)
        
        return {
            "defects": defects,
            "score": score
        }

# Global inspection service instance
inspection_service = InspectionService()
