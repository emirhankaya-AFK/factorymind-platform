from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, JWTError
from sqlalchemy.orm import Session
from . import schemas, database
from .config import settings

# Reusable OAuth2 scheme
security = HTTPBearer()

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(database.get_db)
):
    """
    Validate JWT token and return user
    For MVP, we'll return a mock user if token is present
    In production, implement proper JWT validation
    """
    try:
        # For demo, accept any token that starts with "Bearer "
        # In real app: payload = jwt.decode(credentials.credentials, settings.secret_key, algorithms=[settings.algorithm])
        token = credentials.credentials
        if not token or len(token) < 10:  # Arbitrary minimum length
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        # Mock user - in real app, decode token and fetch user from DB
        return schemas.TokenData(username="admin")
    except jwt.JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )