from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from services.api import models

# Use in-memory SQLite for testing
SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def test_create_organization():
    models.Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        org = models.Organization(name="Test Org Factory")
        db.add(org)
        db.commit()
        db.refresh(org)
        assert org.id is not None
        assert org.name == "Test Org Factory"
    finally:
        db.close()

def test_create_factory():
    models.Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    try:
        org = models.Organization(name="Test Org Line")
        db.add(org)
        db.commit()
        db.refresh(org)
        
        factory = models.Factory(name="Test Factory", location="Test Location", organization_id=org.id)
        db.add(factory)
        db.commit()
        db.refresh(factory)
        assert factory.id is not None
        assert factory.name == "Test Factory"
        assert factory.organization_id == org.id
    finally:
        db.close()
