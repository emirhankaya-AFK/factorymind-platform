def test_telemetry_generator_import():
    """Test that we can import the telemetry generator"""
    from ..telemetry_generator import SyntheticTelemetryGenerator
    gen = SyntheticTelemetryGenerator()
    assert gen is not None

def test_inspection_service_import():
    """Test that we can import the inspection service"""
    from ..inspection import InspectionService
    service = InspectionService()
    assert service is not None