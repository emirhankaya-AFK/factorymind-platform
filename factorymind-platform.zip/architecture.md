# FactoryMind Architecture

## Overview

FactoryMind is a monorepo consisting of:
- Backend: FastAPI application (services/api)
- Frontend: React TypeScript Vite dashboard (apps/web)
- Shared: Domain models and schemas (in services/api)

## Backend Architecture

### Core Components
1. **API Layer**: FastAPI routers for factories, lines, machines, telemetry, inspection, alerts, tickets, model runs
2. **Domain Layer**: SQLAlchemy models and Pydantic schemas
3. **Services Layer**: Business logic for telemetry processing, inspection, alerting, maintenance
4. **Infrastructure Layer**: Database connection, background jobs, WebSocket manager
5. **Cross-cutting**: Configuration, logging, middleware

### Data Flow
- IoT devices send telemetry to `/telemetry/ingest` endpoint
- Telemetry stored in database and broadcast via WebSocket
- Inspection service processes images and produces defect reports
- Alerting service evaluates telemetry and inspection results to create alerts
- Maintenance service creates tickets based on alerts or predictive models

## Frontend Architecture

### Core Components
1. **API Client**: TypeScript wrapper for backend endpoints
2. **State Management**: React Query for server state, Context UI state
3. **Components**: Reusable UI components (charts, tables, forms)
4. **Pages**: Dashboard views (Overview, Machine Health, Alerts, Inspection)
5. **Styles**: Industrial dark theme with CSS modules

### Key Features
- Real-time telemetry charts using WebSocket
- Machine health status visualization
- Alert and ticket management
- Quality inspection interface with image upload and defect highlighting
- Responsive design for industrial touchscreens

## Deployment

### Local Development
- Docker Compose for API, Web, PostgreSQL, Redis
- Hot reload for both backend and frontend

### Production
- Kubernetes manifests in k8s/
- Helm charts available
- Separate deployments for API, Web, Worker, Database, Redis

## Technology Stack

### Backend
- FastAPI
- SQLAlchemy 2.0
- Pydantic
- PostgreSQL/SQLite
- OpenCV
- Redis (for background jobs)
- Python 3.11+

### Frontend
- React 18+
- TypeScript
- Vite
- Tailwind CSS
- Chart.js
- React Query
- Python 3.11+

### DevOps
- Docker
- Docker Compose
- Kubernetes
- GitHub Actions
- Makefile