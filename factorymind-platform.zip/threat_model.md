# Threat Model

## Scope
FactoryMind platform including backend API, frontend dashboard, and data flows.

## Assets
1. Factory telemetry data (sensitive operational data)
2. Inspection images and defect data
3. User credentials and authentication tokens
4. Maintenance records and alert history
5. AI model parameters

## Threats and Mitigations

### T1: Unauthorized API Access
- **Description**: Attacker gains access to API endpoints without authentication
- **Mitigation**: 
  - JWT-based authentication with short-lived tokens
  - Rate limiting on auth endpoints
  - HTTPS enforcement in production

### T2: Data Exposure
- **Description**: Sensitive telemetry or inspection data exposed
- **Mitigation**:
  - Encryption at rest for database
  - Field-level encryption for sensitive data
  - Access control based on roles and organizations
  - Audit logging for data access

### T3: ML Model Poisoning
- **Description**: Attacker injects malicious data to corrupt inspection models
- **Mitigation**:
  - Input validation for inspection images
  - Model versioning and signatures
  - Anomaly detection on training data
  - Secure model update process

### T4: Denial of Service
- **Description**: Overwhelming the system with telemetry or requests
- **Mitigation**:
  - Rate limiting per client/IP
  - Async processing with queue buffering
  - Circuit breaker patterns
  - Autoscaling in Kubernetes

### T5: Insecure WebSocket Communication
- **Description**: Interception or manipulation of WebSocket telemetry stream
- **Mitigation**:
  - WSS (WebSocket Secure) in production
  - Token authentication for WebSocket connections
  - Message validation and sanitization

### T6: Container Breakout
- **Description**: Escape from container to host system
- **Mitigation**:
  - Non-root containers
  - Read-only root filesystem where possible
  - Dropping unnecessary capabilities
  - Regular vulnerability scanning

## Data Flow Security

### Telemetry Ingestion
1. Device → API Gateway (TLS) → Auth → Validation → Database
2. Controls: Mutual TLS for device authentication (future), input validation, rate limiting

### Inspection Processing
1. Upload → Storage (encrypted) → Processing (sandboxed) → Results → Database
2. Controls: File type validation, virus scanning, resource limits, sandboxed execution

### Alert Generation
1. Telemetry/Inspection → Alert Engine (rules-based) → Notification → Database
2. Controls: Role-based access to alert actions, audit trail

## Security Features by Component

### Backend
- Authentication: JWT with refresh tokens
- Authorization: RBAC with organization scoping
- Input Validation: Pydantic schemas
- Output Encoding: Automatic in FastAPI
- Logging: Structured logging with request IDs
- Dependencies: Regular updates via pip-audit

### Frontend
- XSS Prevention: React auto-escaping, Content Security Policy
- CSRF Protection: Same-site cookies, double-submit cookie
- Data Protection: Secure storage of tokens, minimal local storage
- Dependency Safety: npm audit, lockfile

### Infrastructure
- Secrets Management: Environment variables, Docker secrets (future)
- Network Segmentation: Separate networks for frontend/backend/database
- Monitoring: Health checks, metrics, logging
- Backup: Automated database backups, disaster recovery plan

## Compliance
- GDPR ready: Data minimization, right to erasure procedures
- ISO 27001 aligned: Access controls, asset management, incident response
- SOC 2 Type II: Security, availability, confidentiality principles