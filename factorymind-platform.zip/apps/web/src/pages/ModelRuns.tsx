import React from 'react'
import { useQuery } from '@tanstack/react-query'
import { api } from '../api/client'

const ModelRuns = () => {
  const { data: runs, isLoading } = useQuery({
    queryKey: ['model-runs'],
    queryFn: api.getModelRuns,
  })

  if (isLoading) return <p className="text-center py-8">Loading model runs...</p>

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Model Runs</h1>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Machine</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Model Type</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Version</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Timestamp</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {runs?.map((run) => (
              <tr key={run.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{run.id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">{run.machine_id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">{run.model_type}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">{run.model_version}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">{new Date(run.timestamp).toLocaleString()}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button className="text-blue-600 hover:text-blue-900">View Details</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default ModelRuns