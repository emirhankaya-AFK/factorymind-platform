import React, { useState } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import { api } from '../api/client'

const Inspection = () => {
  const [imageUrl, setImageUrl] = useState<string>('')
  const [inspectionResult, setInspectionResult] = useState<any>(null)
  const [isInspecting, setIsInspecting] = useState(false)

  const { data: inspections, isLoading } = useQuery({
    queryKey: ['inspections'],
    queryFn: api.getInspections,
  })

  const inspectMutation = useMutation({
    mutationFn: api.createInspection,
    onSuccess: (data) => {
      setInspectionResult(data)
      setIsInspecting(false)
    },
    onError: (error) => {
      console.error('Inspection failed:', error)
      setIsInspecting(false)
    }
  })

  const handleInspect = async () => {
    if (!imageUrl) return
    setIsInspecting(true)
    try {
      await inspectMutation.mutateAsync({
        machine_id: 1, // For demo, use fixed machine ID
        image_url: imageUrl,
        inspector_id: 1
      })
    } catch (err) {
      setIsInspecting(false)
    }
  }

  if (isLoading) return <p className="text-center py-8">Loading inspections...</p>

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Quality Inspection</h1>
      
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Upload Image for Inspection</h2>
        <div className="space-y-4">
          <input
            type="text"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            placeholder="Enter image URL"
            className="w-full px-4 py-2 border rounded"
          />
          <button
            onClick={handleInspect}
            disabled={isInspecting}
            className="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700"
          >
            {isInspecting ? 'Inspecting...' : 'Run Inspection'}
          </button>
        </div>
        
        {inspectionResult && (
          <div className="mt-6 p-4 bg-gray-50 rounded">
            <h3 className="text-lg font-bold mb-2">Inspection Results</h3>
            <p className="mb-2">Defect Score: {(inspectionResult.score || 0).toFixed(2)}</p>
            <p className="mb-2">Defects Found: {inspectionResult.defects?.length || 0}</p>
            {inspectionResult.defects && inspectionResult.defects.length > 0 && (
              <ul className="list-disc pl-5">
                {inspectionResult.defects.map((defect: any, index: number) => (
                  <li key={index}>
                    {defect.type} (confidence: {(defect.confidence || 0).toFixed(2)})
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
      
      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-bold mb-4">Recent Inspections</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Machine</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Score</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Defects</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {inspections?.map((inspection) => (
                <tr key={inspection.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{inspection.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">{inspection.machine_id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">{Number(inspection.score || 0).toFixed(2)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">{inspection.defects?.length || 0}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">{new Date(inspection.timestamp).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default Inspection