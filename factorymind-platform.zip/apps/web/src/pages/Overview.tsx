import React, { useEffect, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { api } from '../api/client'

const Overview = () => {
  const { data: stats } = useQuery({
    queryKey: ['overview'],
    queryFn: api.getOverview,
  })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Factory Overview</h1>
      
      {!stats ? (
        <p className="text-gray-500">Loading...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-900">Factories</h3>
            <p className="text-3xl font-bold">{stats?.factories || 0}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-900">Machines</h3>
            <p className="text-3xl font-bold">{stats?.machines || 0}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-900">Active Alerts</h3>
            <p className="text-3xl font-bold text-red-500">{stats?.active_alerts || 0}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold text-gray-900">Today's Inspections</h3>
            <p className="text-3xl font-bold">{stats?.inspections_today || 0}</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default Overview