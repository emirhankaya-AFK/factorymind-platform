import React, { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { api } from '../api/client'
import { MachineChart } from '../components/MachineChart'

const Machines = () => {
  const { data: machines, isLoading } = useQuery({
    queryKey: ['machines'],
    queryFn: api.getMachines,
  })

  const [selectedMachineId, setSelectedMachineId] = useState<number | null>(null)

  if (isLoading) return <p className="text-center py-8">Loading machines...</p>

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Machines</h1>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {machines?.map((machine) => (
              <tr key={machine.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{machine.id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{machine.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{machine.type}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${machine.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {machine.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button 
                    onClick={() => setSelectedMachineId(machine.id)}
                    className="text-indigo-600 hover:text-indigo-900"
                  >
                    Details
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {selectedMachineId && (
        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">Machine {selectedMachineId} Details</h2>
          <MachineChart machineId={selectedMachineId} />
        </div>
      )}
    </div>
  )
}

export default Machines