import React from 'react'
import { Link } from 'react-router-dom'

export const Sidebar = () => {
  return (
    <aside className="bg-gray-900 text-white w-64">
      <div className="p-4">
        <div className="font-bold text-lg mb-4">Navigation</div>
        <nav>
          <Link to="/overview" className="block py-2 pl-3 pr-4 rounded hover:bg-gray-800">Overview</Link>
          <Link to="/machines" className="block py-2 pl-3 pr-4 rounded hover:bg-gray-800">Machines</Link>
          <Link to="/alerts" className="block py-2 pl-3 pr-4 rounded hover:bg-gray-800">Alerts</Link>
          <Link to="/tickets" className="block py-2 pl-3 pr-4 rounded hover:bg-gray-800">Tickets</Link>
          <Link to="/inspection" className="block py-2 pl-3 pr-4 rounded hover:bg-gray-800">Inspection</Link>
          <Link to="/models" className="block py-2 pl-3 pr-4 rounded hover:bg-gray-800">Model Runs</Link>
        </nav>
      </div>
    </aside>
  )
}