import React, { useEffect, useState } from 'react'
import { Chart, registerables } from 'chart.js'
import { useQuery } from '@tanstack/react-query'
import { api } from '../api/client'

// Register chart.js components
Chart.register(...registerables)

interface MachineChartProps {
  machineId: number
}

const MachineChart = ({ machineId }: MachineChartProps) => {
  const [chart, setChart] = useState<Chart | null>(null)
  const { data: telemetry, isLoading } = useQuery({
    queryKey: ['telemetry', machineId],
    queryFn: () => api.getTelemetry(machineId),
    refetchInterval: 5000, // Refresh every 5 seconds
  })

  useEffect(() => {
    if (telemetry && telemetry.length > 0) {
      const ctx = document.getElementById(`telemetry-chart-${machineId}`) as HTMLCanvasElement
      
      // Destroy existing chart if any
      if (chart) {
        chart.destroy()
      }
      
      // Prepare data
      const labels = telemetry.map(t => new Date(t.timestamp).toLocaleTimeString())
      const temperatureData = telemetry.map(t => t.readings?.temperature || 0)
      const vibrationData = telemetry.map(t => t.readings?.vibration || 0)
      
      // Create new chart
      const newChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Temperature (°C)',
              data: temperatureData,
              borderColor: 'rgb(255, 99, 132)',
              backgroundColor: 'rgba(255, 99, 132, 0.5)',
              tension: 0.1
            },
            {
              label: 'Vibration',
              data: vibrationData,
              borderColor: 'rgb(54, 162, 235)',
              backgroundColor: 'rgba(54, 162, 235, 0.5)',
              tension: 0.1
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'top' as const
            }
          },
          scales: {
            y: {
              beginAtZero: false
            }
          }
        }
      })
      
      setChart(newChart)
    }
  }, [telemetry, chart, machineId])

  if (isLoading) {
    return <p className="text-center py-8">Loading telemetry data...</p>
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <h2 className="text-xl font-bold mb-4">Telemetry Trends</h2>
      <div className="relative">
        <canvas id={`telemetry-chart-${machineId}`} height="200" />
      </div>
    </div>
  )
}

export default MachineChart