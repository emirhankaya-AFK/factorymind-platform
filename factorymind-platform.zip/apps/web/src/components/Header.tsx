import React from 'react'
import { Link } from 'react-router-dom'

export const Header = () => {
  return (
    <header className="bg-gray-800 text-white px-6 py-4 shadow">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="text-xl font-bold">
          <Link to="/">FactoryMind</Link>
        </div>
        <div className="flex space-x-4">
          <Link to="/overview" className="hover:text-gray-300">Overview</Link>
          <Link to="/machines" className="hover:text-gray-300">Machines</Link>
          <Link to="/alerts" className="hover:text-gray-300">Alerts</Link>
          <Link to="/inspection" className="hover:text-gray-300">Inspection</Link>
        </div>
      </div>
    </header>
  )
}