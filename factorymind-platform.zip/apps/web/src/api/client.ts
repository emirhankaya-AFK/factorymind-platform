import axios from 'axios'

// Create axios instance with base URL
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
  headers: {
    'Content-Type': 'application/json',
  }
})

// Request interceptor to add auth token
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// API methods
export const api = {
  // Overview
  getOverview: () => apiClient.get('/overview').then(res => res.data),
  
  # Machines
  getMachines: () => apiClient.get('/machines/').then(res => res.data),
  
  # Telemetry
  getTelemetry: (machineId: number) => 
    apiClient.get(`/telemetry/?machine_id=${machineId}`).then(res => res.data),
  
  # Alerts
  getAlerts: () => apiClient.get('/alerts/').then(res => res.data),
  
  # Inspections
  getInspections: () => apiClient.get('/inspections/').then(res => res.data),
  createInspection: (data: any) => 
    apiClient.post('/inspections/', data).then(res => res.data),
  
  # Tickets
  getTickets: () => apiClient.get('/tickets/').then(res => res.data),
  
  # Model Runs
  getModelRuns: () => apiClient.get('/model-runs/').then(res => res.data),
}

// Auth helpers
export const auth = {
  login: (username: string, password: string) => 
    apiClient.post('/token', { username, password }).then(res => res.data),
  
  logout: () => {
    localStorage.removeItem('access_token')
  }
}