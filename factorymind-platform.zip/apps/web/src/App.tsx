import React from 'react'
import { BrowserRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { routes } from './routes'
import { Layout } from './components/Layout'

const queryClient = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Layout>
          {routes.map((route, index) => (
            <route.element key={index} />
          ))}
        </Layout>
      </BrowserRouter>
    </QueryClientProvider>
  )
}

export default App