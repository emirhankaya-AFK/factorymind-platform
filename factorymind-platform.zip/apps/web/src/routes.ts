import { lazy } from 'react'
import Overview from './pages/Overview'
import Machines from './pages/Machines'
import Alerts from './pages/Alerts'
import Inspection from './pages/Inspection'
// Lazy load other pages for code splitting
const Tickets = lazy(() => import('./pages/Tickets'))
const ModelRuns = lazy(() => import('./pages/ModelRuns'))

export const routes = [
  { path: '/', element: <Overview /> },
  { path: '/overview', element: <Overview /> },
  { path: '/machines', element: <Machines /> },
  { path: '/alerts', element: <Alerts /> },
  { path: '/inspection', element: <Inspection /> },
  { path: '/tickets', element: <Tickets /> },
  { path: '/model-runs', element: <ModelRuns /> },
]