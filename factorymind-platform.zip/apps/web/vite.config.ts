import { defineConfig } from 'vite'
import pluginReact from '@vitejs/plugin-react'
import { VitePluginESLint } from 'vite-plugin-eslint'

export default defineConfig({
  plugins: [
    pluginReact(),
    VitePluginESLint({
      failOnError: false,
      failOnWarning: false,
    })
  ],
  server: {
    port: 5173,
    strictPort: true,
    host: true,
    origin: "http://0.0.0.0:5173"
  },
  preview: {
    port: 5173,
    strictPort: true
  },
  resolve: {
    alias: {
      '@': '/src'
    }
  }
})