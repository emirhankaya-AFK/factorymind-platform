# API Examples

## Base URL
`http://localhost:8000`

## Authentication
All endpoints (except health) require Bearer token:
```
Authorization: Bearer <access_token>
```

## Health Check
```bash
curl http://localhost:8000/health
```

## Factories
### List factories
```bash
curl -X 'GET' \
  'http://localhost:8000/factories/' \
  -H 'accept: application/json'
```

### Create factory
```bash
curl -X 'POST' \
  'http://localhost:8000/factories/' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "Factory A",
    "location": "Building 1",
    "timezone": "UTC"
  }'
```

## Telemetry
### Ingest telemetry reading
```bash
curl -X 'POST' \
  'http://localhost:8000/telemetry/ingest' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
    "machine_id": 1,
    "timestamp": "2026-10-08T10:00:00Z",
    "readings": {
      "temperature": 25.5,
      "vibration": 0.2,
      "pressure": 101.3
    }
  }'
```

### Query telemetry
```bash
curl -X 'GET' \
  'http://localhost:8000/telemetry/?machine_id=1&limit=100' \
  -H 'accept: application/json'
```

## Inspection
### Create inspection
```bash
curl -X 'POST' \
  'http://localhost:8000/inspections/' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
    "machine_id": 1,
    "image_url": "https://example.com/image.jpg",
    "inspector_id": 1
  }'
```

### Get inspection details
```bash
curl -X 'GET' \
  'http://localhost:8000/inspections/1' \
  -H 'accept: application/json'
```

## Alerts
### List active alerts
```bash
curl -X 'GET' \
  'http://localhost:8000/alerts/?status=active' \
  -H 'accept: application/json'
```

### Acknowledge alert
```bash
curl -X 'PATCH' \
  'http://localhost:8000/alerts/1/acknowledge' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
    "user_id": 1
  }'
```

## Maintenance Tickets
### Create ticket
```bash
curl -X 'POST' \
  'http://localhost:8000/tickets/' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
    "title": "Replace sensor on Line 1",
    "description": "Temperature sensor drifting",
    "machine_id": 1,
    "priority": "high"
  }'
```

## WebSocket
### Telemetry stream
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/telemetry');
ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('Telemetry:', data);
};
```